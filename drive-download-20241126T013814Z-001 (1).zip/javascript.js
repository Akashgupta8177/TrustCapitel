function validateForm() 
{
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const message = document.getElementById('message');

    if (name === '' || email === '' || password === '') {
        message.textContent = 'All fields are required!';
        return;
    }

    // Email validation (basic regex)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        message.textContent = 'Please enter a valid email address!';
        return;
    }

      // mobile number validation (basic regex)

          // Mobile number validation rules
    const mobileRegex = /^[0-9]{10}$/; // Accepts exactly 10 digits

    if (mobile === '') {
        message.textContent = 'Mobile number is required!';
        return;
    }

    if (!mobileRegex.test(mobile)) {
        message.textContent = 'Please enter a valid 10-digit mobile number!';
        return;
    }
     //  birthday validation rules

    if (!dobInput) {
        document.getElementById("result").textContent = "Please enter your date of birth.";
        return;
    }

    const dob = new Date(dobInput);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const monthDifference = today.getMonth() - dob.getMonth();
    const dayDifference = today.getDate() - dob.getDate();

    // Adjust for month or day differences if birthday hasn't occurred yet this year
    if (monthDifference < 0 || (monthDifference === 0 && dayDifference < 0)) {
        age--;
    }

        const genderInputs = document.getElementsByName("gender");
        let selectedGender = null;

        // Loop through the radio buttons to find the selected one
        for (const input of genderInputs) {
            if (input.checked) {
                selectedGender = input.value;
                break;
            }
        }

        // Display the result
        const result = document.getElementById("result");
        if (selectedGender) {
            result.textContent = You-{selectedGender};// Display the errer
    } else {
            result.textContent = "Please select a gender.";}


            // Display the state



            if (selectedState) {
                result.textContent = You -{selectedState};
            } else 
                result.textContent = "Please select a state.";// Display the errer

                // Display Your PIN code


                function validatePin() {
                    const pinCode = document.getElementById("pincode").value;
                    const result = document.getElementById("result");
        
                    // Regular expression to match a 6-digit PIN code (common in many countries)
                    const pinRegex = /^\d{6}$/;
        
                    if (pinRegex.test(pinCode)) {
                        result.textContent = Your - "${pinCode}" ;// Display the errer
                        result.style.color = "green";
                    } else {
                        result.textContent = "Invalid PIN code. Please enter a 6-digit number.";
                        result.style.color = "red";}
                    }


                      // Regular expression to validate 12-digit Aadhaar number
            const aadhaarRegex = /^\d{12}$/;

            if (aadhaarRegex.test(aadhaarInput)) {
                result.textContent = Your- "${aadhaarInput}" ;// Display the errer
                result.style.color = "green";
            } else {
                result.textContent = "Invalid Aadhaar number. Please enter a 12-digit numeric value.";
                result.style.color = "red"}





                // Display the PAN card number


        
                    if (panRegex.test(panInput)) {
                        message.textContent = "Valid PAN card number!";
                        message.className = 'success';
                    } else {
                        message.textContent = "Invalid PAN card number. Please follow the format: AAAAA9999A.";
                        message.className = 'error';}




}